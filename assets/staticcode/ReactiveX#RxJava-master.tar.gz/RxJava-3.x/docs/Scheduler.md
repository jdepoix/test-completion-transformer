If you want to introduce multithreading into your cascade of Observable operators, you can do so by instructing those operators (or particular Observables) to operate on particular Schedulers.

For more information about Schedulers, see [the ReactiveX `Scheduler` documentation page](http://reactivex.io/documentation/scheduler.html).